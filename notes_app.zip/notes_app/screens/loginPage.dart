import 'package:flutter/material.dart';
import 'package:notes/screens/homepage.dart';
import 'package:notes/screens/registerPage.dart';
import 'package:notes/services/userauth.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  @override
  Widget build(BuildContext context) {
    final GlobalKey<FormFieldState> _formKey = GlobalKey();
  TextEditingController passwordController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  UserAuth firebaseAuth = UserAuth();
    return SafeArea(child: 
    Scaffold(
      appBar: AppBar(
        actions: [IconButton(onPressed: (){
          Navigator.of(context).push(MaterialPageRoute(builder: (_)=> RegisterPage()));
        }, icon: const Icon(Icons.arrow_back_ios))],
      ),
      body: Form(
        key: _formKey,
        child: Column(
        children: [        
          TextFormField(
            decoration: const InputDecoration(hintText: "Enter Email Adress"),
            controller: emailController,
          ),
          TextFormField(
            decoration: const InputDecoration(hintText: "Enter Password"),
            controller: passwordController,
          ),
          OutlinedButton(onPressed: () async{
            //_formKey.currentState!.validate();
            String loginEmail = await firebaseAuth.loginUser(              
              loginEmail: emailController.text,
              loginPassword: passwordController.text,
            );
            // ignore: use_build_context_synchronously
            Navigator.push(context, MaterialPageRoute(builder: (_) => const HomeScreen()));
            //print("the user is successfully logged in with the given email address: $loginEmail");
          }, 
          child: const Text("Login Now")),
        
        ],
      ))));
  }
}