import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:notes/models/note_model.dart';
import 'package:notes/screens/homepage.dart';
import 'package:notes/services/userauth.dart';


class CreateNote extends StatefulWidget {
  const CreateNote({super.key, required this.onNewNoteCreated, required this.userauth, required this.noteId});
  final Function(Note) onNewNoteCreated;
  final UserAuth userauth;
  final String noteId;


  @override
  State<CreateNote> createState() => _CreateNoteState();
}

class _CreateNoteState extends State<CreateNote> {
  TextEditingController titleController = TextEditingController();
  TextEditingController bodyController = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          title: const Text("New Note"),
          actions: [
            IconButton(onPressed: (){
            if (titleController.text.isEmpty && bodyController.text.isEmpty){
              return;
            }
            else{
              Navigator.of(context).push(MaterialPageRoute(builder: (_)=> const HomeScreen()));
            }
            
            
            final note = Note(body: bodyController.text, title: titleController.text, noteId: widget.noteId);
            widget.onNewNoteCreated(note);
            widget.userauth.storeNotes(
              title: titleController.text, 
              body: bodyController.text, 
              noteId: widget.noteId);
          }, icon: const Icon(Icons.save))],
        ),
        body: Padding(
          padding: const EdgeInsets.all(10.0),
          child: Column(
            children: [
              TextFormField(
                style: const TextStyle(
                  fontSize: 30
                ),
                decoration: const InputDecoration(
                  border: InputBorder.none,
                  hintText: "Title",
                ),
                controller: titleController,
              ),
              const SizedBox(height: 10,),
              TextFormField(
                style: const TextStyle(
                  fontSize: 15
                ),
                decoration: const InputDecoration(
                  border: InputBorder.none,
                  hintText: "Content",
                
                ),
                controller: bodyController,
              )
            ],
          ),
        ),
      ));
  }
}