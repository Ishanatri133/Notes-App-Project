import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart'; // Import Firestore
import 'package:notes/models/note_model.dart';

class NoteView extends StatelessWidget {
  const NoteView({Key? key, required this.noteId, required this.onNoteDeleted, required int index})
      : super(key: key);

  final String noteId; // Assuming you're passing the Firestore document ID
  final Function(int) onNoteDeleted;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Note View"),
        actions: [
          IconButton(
            onPressed: () async {
              // Delete the note from Firestore and call onNoteDeleted
              await FirebaseFirestore.instance.collection("notes").doc(noteId).delete();
              onNoteDeleted(-1);
              Navigator.of(context).pop(noteId);
            },
            icon: const Icon(Icons.delete),
          ),
        ],
      ),
      body: FutureBuilder<DocumentSnapshot<Map<String, dynamic>>>(
        future: FirebaseFirestore.instance.collection("notes").doc(noteId).get(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return CircularProgressIndicator(); // Show loading indicator while fetching data
          }
          if (snapshot.hasError) {
            return Text("Error: ${snapshot.error}");
          }

          final noteData = snapshot.data!.data();

          if (noteData == null) {
            return Text("Note not found");
          }

          final note = Note(
            title: noteData['title'] ?? '',
            body: noteData['body'] ?? '',
            noteId: noteData['noteId'] ?? '',
          );

          return Padding(
            padding: const EdgeInsets.all(10),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  note.title,
                  style: TextStyle(
                    fontSize: 26,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 10),
                Text(
                  note.body,
                  style: TextStyle(
                    fontSize: 18,
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
