import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:notes/screens/create_note.dart';
import 'package:notes/models/note_model.dart';
import 'package:notes/screens/noteview.dart';
import 'package:notes/screens/registerPage.dart';
import 'package:notes/services/userauth.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<Note> notes = [];
  UserAuth userAuth = UserAuth();
  String userEmail = ''; // Initialize userEmail here

  @override
  void initState() {
    super.initState();
    fetchUserEmail();
    fetchNotes();
  }

  Future<void> fetchUserEmail() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      setState(() {
        userEmail = user.email!;
      });
    }
  }

  Future<void> fetchNotes() async {
    if (userEmail.isEmpty) {
      return;
    }

    final notesCollection =
        FirebaseFirestore.instance.collection("userData").doc(userEmail).collection("notes");

    final querySnapshot = await notesCollection.get();

    setState(() {
      notes = querySnapshot.docs.map(
        (doc) {
          Map<String, dynamic> data =
              doc.data() as Map<String, dynamic>;
          return Note(
            noteId: doc.id,
            title: data['title'] ?? '',
            body: data['body'] ?? '',
          );
        },
      ).toList();
    });
  }
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          title: const Text("Notes App"),
          actions: [
    IconButton(
      onPressed: () async {
        // Implement logout functionality here
        await userAuth.logoutUser(); // Assuming you have a logoutUser method in your UserAuth class
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) => const RegisterPage()),
        );
      },
      icon: const Icon(Icons.logout),
    ),
  ],
        ),
        floatingActionButton: FloatingActionButton(
          onPressed: () async {
            final noteId =
                FirebaseFirestore.instance.collection("userData").doc(userEmail).collection("notes").doc().id;
            final result = await Navigator.of(context).push(MaterialPageRoute(
              builder: (_) => CreateNote(
                onNewNoteCreated: onNewNoteCreated,
                userauth: userAuth,
                noteId: noteId,
              ),
            ));
            if (result != null && result is String) {
              final deletedNoteId = result;
              final deletedIndex = notes
                  .indexWhere((note) => note.noteId == deletedNoteId);
              if (deletedIndex != -1) {
                onNoteDeleted(deletedIndex);
              }
            }
          },
          child: const Icon(Icons.add),
        ),
        body: ListView.builder(
          itemCount: notes.length,
          itemBuilder: (context, index) {
            return InkWell(
              onTap: () {
                Navigator.of(context).push(MaterialPageRoute(
                  builder: (_) => NoteView(
                    noteId: notes[index].noteId,
                    index: index,
                    onNoteDeleted: (int index) {
                      onNoteDeleted(index);
                    },
                  ),
                ));
              },
              child: Card(
                child: Padding(
                  padding: EdgeInsets.all(10),
                  child: Column(
                    children: [
                      Text(
                        notes[index].title,
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Text(
                        notes[index].body,
                        style: TextStyle(
                          fontSize: 10,
                        ),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  void onNewNoteCreated(Note note) {
    notes.add(note);
    setState(() {});
  }

  void onNoteDeleted(int index) {
    notes.removeAt(index);
    setState(() {});
  }
}
