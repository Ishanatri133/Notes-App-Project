import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
//import 'package:notes/screens/homepage.dart';
import 'package:notes/screens/registerPage.dart';

void main() async{
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(MaterialApp(
    home: const RegisterPage(),
    theme: ThemeData(brightness: Brightness.dark, primarySwatch: Colors.purple)
  ));
  }