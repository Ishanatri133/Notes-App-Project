import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class UserAuth{
  final FirebaseAuth _auth = FirebaseAuth.instance;
  FirebaseFirestore firestoreDB = FirebaseFirestore.instance;
  registerUser(
    {required String firstName,
    required String lastName, 
    required String phoneNumber, 
    required String registerEmail, 
    required String registerPassword}) async {
      UserCredential userCreds =  await _auth.createUserWithEmailAndPassword(email: registerEmail, password: registerPassword);
      storeUserDataInFireStore(firstName: firstName, lastName: lastName, phoneNumber: phoneNumber, firestoreEmail: registerEmail, firestorePassword: registerPassword);
      return userCreds.user!.email;
    }
  loginUser({required String loginEmail, required String loginPassword}) async{
    UserCredential loginCreds = await _auth.signInWithEmailAndPassword(email: loginEmail, password: loginPassword);
    if (loginCreds.user != null){
      print("Login Success");
      return loginCreds.user!.email;
    }

  }
  Future <void> logoutUser() async{
    try{
      await _auth.signOut();
    }catch(e){
      print("Error logging out $e");
    }
  }
  storeUserDataInFireStore({required String firstName,
    required String lastName, 
    required String phoneNumber, 
    required String firestoreEmail, 
    required String firestorePassword}) async{
      Map <String, dynamic>userDataMap = {
        'fName': firstName,
        'lName': lastName,
        'phoneNumber': phoneNumber,
        'email': firestoreEmail,
        'password': firestorePassword,
      };
      await firestoreDB.collection("userData").doc(firestoreEmail).set(userDataMap).whenComplete(()  {print('user data is successfully added to the database');});
    }

    storeNotes({required String title, required String body, required String noteId}) async{
      if (_auth.currentUser!=null){
        String currentUserEmail = _auth.currentUser!.email!;
      Map<String, String> notesMap = {
        'title': title,
        'body' : body,
      };
      await firestoreDB
      .collection("userData")
      .doc(currentUserEmail)
      .collection("notes")
      .add(notesMap)
      .then((value) {
        print("note added to firestore with ID: ${value.id}");
      }).catchError((error){
        print("failed to add note $error");
      });
    }
    }

    
}